---
name: Documentation Issue
about: Corrections, improvements or requests for new content on Solidity's documentation.
title: ''
labels: 'documentation :book:'
assignees: ''

---

## Page

<!--Please link directly to the page which you think has a problem.-->

## Abstract

<!--Please describe in detail what is wrong.-->

## Pull request

<!--Please link to your pull request which resolves this issue.-->
